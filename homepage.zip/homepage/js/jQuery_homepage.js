$(function(){

    $(".menu>li").mouseover(function() {
        $(".submenu li").stop().slideDown();
    });
    $(".menu>li").mouseout(function() {
        $(".submenu li").stop().slideUp();
    });

        var x = $(".fade img");
        var y = 3;
        setInterval(function() {
            y--;
            if(y==0) {
                x.fadeIn();
                y = 3;
            } else {
                x.eq(y).fadeOut();
            }       
        }, 2000);
    
        // function prevbook(){
        //     $(".bookimg").animate({
        //         marginLeft:50,
        //     },1000)

        // }

        // function nextbook(){
        //     $(".bookimg").animate({
        //         marginRight:50,
        //     },1000)

        // }




})