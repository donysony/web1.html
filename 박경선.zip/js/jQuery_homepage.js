$(function(){


    $(".menu>li").mouseover(function() {
        $(".submenu").stop().slideDown();
    });
    $(".menu>li").mouseout(function() {
        $(".submenu").stop().slideUp();
    });

    // var now=0;
    // var img =3;
    // $(".fade img").eq(0).siblings().hide();
    // function slide(){
    //     if(now == img){
    //         $(".fade img").eq(now).fadeOut(1000);
    //         $(".fade img").eq(0).fadeIn(1000);
    //         now=0;
    //     }else{
    //         $(".fade img").eq(now).fadeOut(1000);
    //         $(".fade img").eq(now-1).fadeIn(1000);
    //         now++;
    //     }
    // }
    // setInterval(slide, 3000);

    // var num=0;
    // prevbook(){
    //     num++;
    //     if(num>6){
    //         num=0;
    //     }
    //     document.getElementsByClassName("book").src="img/book"+num+".png";
    // }
    // nextbook(){
    //     num--;
    //     if(num<0){
    //         num=6;
    //     }
    //     document.getElementsByClassName("book").src="img/book"+num+".png";
    // }




})